function sprite (options) {
			
    var that = {};        
    that.tickCount = 0,
    that.reverse=false,
    that.imageUrl=options.imageUrl;						
    that.context = options.context;
    that.continuous=options.continuous;
    that.width = options.width;
    that.type = options.type||"";
    that.height = options.height;
    that.image = new Image();
    that.beginFromEnd=options.beginFromEnd;
    that.image.src=that.imageUrl;
    that.loop=options.loop;
    that.ended=false;
    that.stopSprite=false;
    that.name=options.name;
    that.frameIndex = 0,
    that.ticksPerFrame = options.ticksPerFrame || 0,
    that.numberOfFrames = options.numberOfFrames || 1,
    
that.resumeSprite=function(){
	   that.stopSprite=false;	  
};

that.restartSprite=function(){
	   that.tickCount=0;
	   that.frameIndex=0;
	   that.reverse=false;
	   that.resumeSprite();
	   that.ended=false;
	   //that.update();
	   //that.render();
};  

that.update = function() {
    	   if(that.stopSprite==true)return;
           if(that.loop){
			
			  if(!that.reverse)
				{
				  updateForward();
				}
	  	 	  else 
				{
				  updateBackward();
				}
   	  		 }

   	   else
		{      
                        if(that.beginFromEnd==true)updateBackward();
			else updateForward();
		}

   }; 

that.paint=function(frameOriginX,frameOriginY,xPosition,yPosition,frameWidth,frameHeight,previousWidth,previousHeight,fliped){
 	  if(fliped==true){
		that.context.imageSmoothingEnabled = false;	
	   	that.context.save();
	 	that.context.translate(xPosition + frameWidth, yPosition + frameHeight);
   	 	that.context.rotate(180*Math.PI/180);
		that.context.scale(1, -1);
	 	that.context.translate(-(xPosition + frameWidth), -(yPosition + frameHeight));
	   }

	   var oldYCoord=floor-previousHeight;
 	   that.context.clearRect(xPosition,oldYCoord, previousWidth, previousHeight); 		 
           that.context.drawImage(
           that.image,
           frameOriginX,
           frameOriginY,
           frameWidth,
           frameHeight,
           xPosition,
           yPosition,
           frameWidth,
           frameHeight);
	   if(fliped==true)
	  	that.context.restore();
}

        function updateForward()
	{	
        that.tickCount += 1;
        if (that.tickCount > that.ticksPerFrame)
		 {
        		that.tickCount = 0;
           		if (that.frameIndex < that.numberOfFrames - 1)
				 {	
               				 // Go to the next frame
                 			that.frameIndex += 1; 
           			 }
          		 else {   
					that.reverse=true;
						if(that.loop){
               							 that.frameIndex = that.numberOfFrames - 2;
							     }
						else	     {
								  that.ended=true;
								  if(that.continuous==true)that.frameIndex=0;
							     }						                     
              		       }          
          	 } 
	} 

      function updateBackward()
	{
        that.tickCount += 1;
        if (that.tickCount > that.ticksPerFrame) 
		{
        		that.tickCount = 0;
          		 if (that.frameIndex >0 ) 
				{	
               			 // Go to the next frame
                 			that.frameIndex -= 1; 
           			 }
          		 else   {       that.ended=true; 
               			 	if(that.continuous==true) that.frameIndex = that.numberOfFrames - 1;
					if(that.loop){that.reverse=false;that.frameIndex=0;that.tickCount = that.ticksPerFrame-2;}
                  			 
           			 }           
       		 } 
	} 

    return that;
}
