var lastKeypressTime = 0
var delta = 400;
var keys=[];

//Observer implementation for events treatment. OK lets go there
var EventBus = {
  listeners: {},

  subscribe: function(topic, listener) {
    // create the topic if not yet created
    if(!this.listeners[topic]) this.listeners[topic] = [];

    // add the listener
    this.listeners[topic].push(listener);
  },

  publish: function(topic, data) {

    // return if the topic doesn't exist, or there are no listeners
    if(!this.listeners[topic] || this.listeners[topic].length < 1) return;

    // send the event to all listeners
    this.listeners[topic].forEach(function(listener) {
	//console.log(data);
      listener(data);
    });
  }
};

//Defining default treatment(on Controller.js) for each event troughout EventBus. 
var backwardMoveEvent=1;
var upMoveEvent=2;
var forwardMoveEvent=3;
var downMoveEvent=4;
var releaseEvent=0;
var highPunchEvent=11;
var hookEvent=12;
var finishhookEvent=51;
var alternatePunchHand=52;
EventBus.subscribe(backwardMoveEvent,processBackward);
EventBus.subscribe(upMoveEvent,processUp);
EventBus.subscribe(forwardMoveEvent,processForward);
EventBus.subscribe(downMoveEvent,processDown);
EventBus.subscribe(releaseEvent,processRelease);
EventBus.subscribe(highPunchEvent,processHighPunch);
EventBus.subscribe(hookEvent,processHook);
EventBus.subscribe(finishhookEvent,processFinishHook);
EventBus.subscribe(alternatePunchHand,changeHpHand);


function createPlayerControls(options){
  var controls={};
  controls.forwardMoveCommand      = options.forward,
  controls.backwardMoveCommand     = options.back,
  controls.jumpMoveCommand	   = options.up,
  controls.crunchMoveCommand 	   = options.down,
  controls.punchActionCommand	   = options.punch;

return controls;
}


function detectKeyAction(playerWich){
	var controls= playerWich.controls;
	document.addEventListener('keydown',    onkeydown,    false);
	document.addEventListener('keyup',      onkeyup,      false);

 function onkeydown(e) {
    var e = e || window.event;
    var charCode = (typeof e.which == "number") ? e.which : e.keyCode;

    if (charCode==controls.forwardMoveCommand) {

          keys[charCode]=true;
	  EventBus.publish(forwardMoveEvent,playerWich);	
    }
    else if (charCode==controls.backwardMoveCommand) {
	 keys[charCode]=true;	  
	  EventBus.publish(backwardMoveEvent,playerWich);
    }
    else if (charCode==controls.crunchMoveCommand) {
	 keys[charCode]=true;
	  EventBus.publish(downMoveEvent,playerWich);      
    }
    else if (charCode==controls.jumpMoveCommand) {
	 keys[charCode]=true;
	  EventBus.publish(upMoveEvent,playerWich);             
    }
//now the punching keys
    else if (charCode== controls.punchActionCommand) {
	 keys[charCode]=true;

	 if(keys[controls.crunchMoveCommand]==true){
	  	EventBus.publish(hookEvent,playerWich);    		
	 }
	 else if(keys[controls.forwardMoveCommand]==true){
	  	EventBus.publish(highPunchEvent,playerWich);return;
	 }
             
    }
}

  function onkeyup(e)  {		
     var charCode = (typeof e.which == "number") ? e.which : e.keyCode;

     if(charCode==controls.forwardMoveCommand||charCode==controls.jumpMoveCommand||charCode==controls.crunchMoveCommand||charCode==controls.backwardMoveCommand){
	  keys[charCode]=false; EventBus.publish(releaseEvent,playerWich); 
}
     else if(charCode==controls.punchActionCommand){
	      if(keys[controls.crunchMoveCommand]==true){
	  		EventBus.publish(finishhookEvent,playerWich); return;
		}
     else if(keys[controls.forwardMoveCommand]==true){
	  		EventBus.publish(alternatePunchHand,playerWich);EventBus.publish(releaseEvent,playerWich); 
		}
     }	  
	  
 }
}
