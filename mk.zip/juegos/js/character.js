
function createCharacter(options){
var player={};
player.number=options.player;
player.hpControl=true;
player.xMoveSpeed=options.xSpeed||0;
player.charX=options.X||0;
player.charY=options.Y||floor;
player.controls=options.controls;
player.direction=options.direction
//players sprites
player.fliped=options.fliped;
player.base=options.base;
player.move_forward=options.forward;
player.move_backward=options.backward||0;
player.jump=options.jump||0;
player.crunch=options.crunch||0;
player.current=options.base;
player.moves=[];
player.height=100;
player.width=55;
player.iWillKickYourAss=false;
player.update=function(callback){
	if( player.current.stopSprite==false){
	    player.current.update();
	    paint();
	    callback(this);
	}
}

player.addMove=function(sprite){
	player.moves[sprite.type]=sprite;
}

function getCenterOrigin(arr,index){
	var center=0;
            for(var i=0; i<index;i++){
	        var ep=(arr[i]==undefined?0:arr[i]);
		center+=ep;
	      }
	return center;
}

function paint(){
	var sprite=player.current;
   	var frameIndex=sprite.frameIndex;
	//height	
	var spriteExtraHeight=chargeOffsets(SpritesOffsetHeight,sprite);
	var frameHeight=spriteExtraHeight[frameIndex];

	//width
	var spriteExtraWidth=chargeOffsets(SpritesOffsetWidth,sprite)||[];
        var extraWidth=(spriteExtraWidth[frameIndex]==undefined?0:spriteExtraWidth[frameIndex]);
	var frameWidth= (sprite.width)/sprite.numberOfFrames; 
	var totalWidth=frameWidth+extraWidth;

	//origin coords, floor var defined in Controller.js
	var center=getCenterOrigin(spriteExtraWidth,frameIndex);
	var frameOriginX=frameIndex*(sprite.width)/sprite.numberOfFrames+center;
	var frameOriginY=sprite.height-frameHeight;

	//position where draw in canvas
	var xPos=player.charX;
	var yPos=floor-frameHeight;
	player.charY=yPos;
        player.charX+=player.xMoveSpeed;  
	sprite.paint(frameOriginX,frameOriginY,xPos,yPos,totalWidth,frameHeight,player.width,player.height,player.fliped);    
	player.width= totalWidth;
	player.height=frameHeight;
	//if current frame is a collision frame
	var hitRead=chargeOffsets(collisionIndexes,sprite)||-1;
	if(hitRead==frameIndex&&sprite.tickCount==0)
		player.iWillKickYourAss=true;
}


function chargeOffsets(arr,sprite){
        for(var i=0;i<arr.length;i++){
		if(arr[i].name==sprite.name){
		var woffsets=arr[i].value;
			for(var j=0;j<woffsets.length;j++){
				if(woffsets[j].type==sprite.type){
					return woffsets[j].value;
					}
				}
		}
	 }
}

return player;
}

