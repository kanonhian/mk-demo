
//frame mas grande el del gancho =120
var scorpio_base = sprite({
    context: canvasPlayer1,
    width: 308,
    height: 103,
    ticksPerFrame:15,
    numberOfFrames:6,
    imageUrl:'images/scorpio.png',
    loop:true,
    name: 'Scorpio',
    type: 'base'
});
var scorpio_move_forward = sprite({
    context: canvasPlayer1,
    width: 450,
    continuous:true,
    height: 111,
    ticksPerFrame:15,
    numberOfFrames:9,
    imageUrl:'images/scorpio-forward.png',
    moveSpeed:1,
    loop:false,
    name: 'Scorpio',
    type: 'forward'
});
var scorpio_move_backward = sprite({
    context: canvasPlayer1,
    width: 450,
    beginFromEnd:true,
    continuous:true,
    height: 111,
    ticksPerFrame:15,
    numberOfFrames:9,
    imageUrl:'images/scorpio-forward.png',
    moveSpeed:-1,
    loop:false,
    type: 'backward',
    name: 'Scorpio'
});

var scorpio_crunch = sprite({
    context: canvasPlayer1,
    width: 98,
    height: 80,
    ticksPerFrame:6,
    numberOfFrames:2,
    imageUrl:'images/scorpio-crunch.png',
    loop:false,
    type: 'down',
    name: 'Scorpio'
});

var scorpio_jump = sprite({
    context: canvasPlayer1,
    width: 108,
    height: 111,
    ticksPerFrame:15,
    numberOfFrames:2,
    imageUrl:'images/scorpio-jump.png',
    loop:false,
    jumpSpeed: 1,
    isJumping:true,
    name: 'Scorpio',
    type: 'up',
});

var scorpio_hook = sprite({
    context: canvasPlayer1,
    width: 296,
    height: 120,
    ticksPerFrame:4,
    numberOfFrames:6,
    imageUrl:'images/scorpio-hook.png',
    loop:false,
    type: 'hook',
    name: 'Scorpio'
});

var scorpio_hp_r = sprite({
    context: canvasPlayer1,
    width: 150,
    height: 111,
    ticksPerFrame:5,
    numberOfFrames:3,
    imageUrl:'images/scorpio-hp-r.png',
    loop:false,
    type: 'hp-r',
    name: 'Scorpio'
});

var scorpio_hp_l = sprite({
    context: canvasPlayer1,
    width: 150,
    height: 111,
    ticksPerFrame:5,
    numberOfFrames:4,
    imageUrl:'images/scorpio-hp-l.png',
    loop:false,
    type: 'hp-l',
    name: 'Scorpio'
});

var player1Controls=createPlayerControls({
    back     : 37,
    up       : 38,
    forward  : 39,
    down     : 40,
    punch    : 65
});

var alacran=createCharacter({
    base:scorpio_base,
    forward:scorpio_move_forward,
    backward :scorpio_move_backward,
    crunch : scorpio_crunch,
    jump: scorpio_jump,
    player : 1,
    controls :player1Controls,
    fliped : false,
    direction :1
});
alacran.addMove(scorpio_hook);
alacran.addMove(scorpio_hp_r);
alacran.addMove(scorpio_hp_l);
detectKeyAction(alacran);
player1=alacran;
