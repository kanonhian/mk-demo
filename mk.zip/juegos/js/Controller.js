//------------------------------Collisions, physics and all the stuff-----------------------------------------------
var canvasObject={};
canvasObject.x=0;
canvasObject.width=canvas.width;
canvasObject.y=0;
canvasObject.height=canvas.height;
xSpeed=1;
floor=400;
var gameObjects=[];


//Here comes the colitions indexes
var highPunchColision=100;
var hookColision=101;
var ColisionHandler = {
  handlers: {},

  subscribe: function(topic, listener) {
    if(!this.handlers[topic]) this.handlers[topic] = [];
    this.handlers[topic].push(listener);
  },

  publish: function(topic, data) {
    if(!this.handlers[topic] || this.handlers[topic].length < 1) return;
    this.handlers[topic].forEach(function(listener) {
      listener(data);
    });
  }
};

ColisionHandler.subscribe(highPunchColision,processHighPunchColision);
ColisionHandler.subscribe(hookColision,processHookColision);

function canMove(A){
	if((A.x+A.width<canvasObject.width&&A.x>=canvasObject.x)){   		
		return true;  		
	}
	return false;
}

function geometricDistance(A,B){
	var dx = Math.abs(A.charX-B.charX);
	var dy = Math.abs(A.charY-B.charY);
	var dist = Math.sqrt(dx * dx + dy * dy);
	return dist;
}

function xDistance(A,B){
	return A.charX-B.charX;
}
function canCollideIfWalking(player){
	var source=player;
	var target=(source.number==2?player1:player2);
	var distance=xDistance(source,target);
	if(distance>11&&source.direction==1)
		return true;
	else if(distance<-11&&source.direction==-1)
		return true;
	return false; 

}

function processHighPunchColision(source){
	var target=(source.number==2?player1:player2);
	if(canCollideIfWalking(source))
		console.log("ouch");


}

function processHookColision(player){

}

//--------------------------------------Main function, just that-----------------------------------------------------
function loop(){
	window.requestAnimationFrame(loop);
	for(var i=0; i<gameObjects.length;i++){
	gameObjects[i].update(function(player){
	   	if(player.iWillKickYourAss==true){
			if(player.current.type=='hp-r'||player.current.type=='hp-l')
				ColisionHandler.publish(highPunchColision,player);  
		}
			player.iWillKickYourAss=false;		
		});
	}
}


//---------------------------------------------Treating key events here-----------------------------------------------


function processForward(player){
	var playerDim={ x : player.charX + xSpeed,
                width :player.width,
	        y: player.charY,
		height:120
		       };

	if(canMove(playerDim)){
		if(canCollideIfWalking(player)){
			player.xMoveSpeed=0;
			player.current=player.move_forward;
			return;		
		}
		if(player.fliped)
			player.xMoveSpeed=-xSpeed
		else
			player.xMoveSpeed=xSpeed;
		player.current=player.move_forward;	
	}
	else{
		player.xMoveSpeed=0;adjustPositionX(player);
	}

}
function adjustPositionX(player){
	if(player.charX+player.width>canvasObject.width)
		player.charX=canvasObject.width-player.width;

	else if(player.charX<canvasObject.x)
		player.charX=canvasObject.x;
}
function processBackward(player){
	var playerDim={ x : player.charX - xSpeed,
                width :player.width,
	        y: player.charY,
		height:120
		       };

	if(canMove(playerDim)==true){
		if(player.fliped)
			player.xMoveSpeed=xSpeed
		else
			player.xMoveSpeed=-xSpeed;
		player.current=player.move_backward;	
	}
	else{ 
		player.xMoveSpeed=0;adjustPositionX(player);
	}

}
function processUp(player){
//We are not jumping yet, so no worry about checking if possible 
	player.current=player.jump;
	if(player.current.ended==true)
	    player.current.stopSprite=true;
 

}
function processDown(player){
	    player.current=player.crunch;
	   if(player.current.ended==true)
   		player.current.stopSprite=true;
	     

}
function processRelease(player){
	player.current.restartSprite();
	player.current=player.base;
	player.xMoveSpeed=0;
}
function processHighPunch(player){

	stopMovement(player);
	if(player.hpControl==true){
	    player.current=player.moves['hp-r'];
	}
	else if(player.hpControl==false){
   	    player.current=player.moves['hp-l'];
	}

	var stoped=stopAnimation(player.current);
	if(stoped){
	    player.hpControl=!player.hpControl;
	    player.current.restartSprite();
	}	
}
function changeHpHand(player){
	player.hpControl=!player.hpControl;
	}
function processHook(player){
	player.current=player.moves['hook'];
	stopAnimation(player.current);
}

function processFinishHook(player){
	player.moves['hook'].restartSprite();
	player.current=player.crunch;

}

//auxiliar function, its simple because again we dont jump yet
function stopMovement(player){
	if(player.xMoveSpeed!=0){
	    player.xMoveSpeed=0; 
	    return true;
	   }
	return false;
}

function stopAnimation(sprite){
	if(sprite.ended==true){
	    sprite.stopSprite=true;
	 }
return sprite.ended;
}
//eof
