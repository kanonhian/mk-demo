
//frame mas grande el del gancho =120
var scorpio_base2 = sprite({
    context: canvasPlayer2,
    width: 308,
    height: 103,
    ticksPerFrame:15,
    numberOfFrames:6,
    imageUrl:'images/scorpio.png',
    loop:true,
    name: 'Scorpio',
    type: 'base'
});
var scorpio_move_forward2 = sprite({
    context: canvasPlayer2,
    width: 450,
    continuous:true,
    height: 111,
    ticksPerFrame:15,
    numberOfFrames:9,
    imageUrl:'images/scorpio-forward.png',
    moveSpeed:1,
    loop:false,
    name: 'Scorpio',
    type: 'forward'
});
var scorpio_move_backward2 = sprite({
    context: canvasPlayer2,
    width: 450,
    beginFromEnd:true,
    continuous:true,
    height: 111,
    ticksPerFrame:15,
    numberOfFrames:9,
    imageUrl:'images/scorpio-forward.png',
    moveSpeed:-1,
    loop:false,
    type: 'backward',
    name: 'Scorpio'
});

var scorpio_crunch2 = sprite({
    context: canvasPlayer2,
    width: 98,
    height: 80,
    ticksPerFrame:8,
    numberOfFrames:2,
    imageUrl:'images/scorpio-crunch.png',
    loop:false,
    type: 'down',
    name: 'Scorpio'
});

var scorpio_jump2 = sprite({
    context: canvasPlayer2,
    width: 108,
    height: 111,
    ticksPerFrame:15,
    numberOfFrames:2,
    imageUrl:'images/scorpio-jump.png',
    loop:false,
    jumpSpeed: 1,
    isJumping:true,
    name: 'Scorpio',
    type: 'up',
});

var scorpio_hook2 = sprite({
    context: canvasPlayer2,
    width: 296,
    height: 120,
    ticksPerFrame:4,
    numberOfFrames:6,
    imageUrl:'images/scorpio-hook.png',
    loop:false,
    type: 'hook',
    name: 'Scorpio'
});

var scorpio_hp_r2 = sprite({
    context: canvasPlayer2,
    width: 150,
    height: 111,
    ticksPerFrame:5,
    numberOfFrames:3,
    imageUrl:'images/scorpio-hp-r.png',
    loop:false,
    type: 'hp-r',
    name: 'Scorpio'
});

var scorpio_hp_l2 = sprite({
    context: canvasPlayer2,
    width: 150,
    height: 111,
    ticksPerFrame:5,
    numberOfFrames:4,
    imageUrl:'images/scorpio-hp-l.png',
    loop:false,
    type: 'hp-l',
    name: 'Scorpio'
});

var player2Controls=createPlayerControls({
    back     : 76,
    up       : 73,
    forward  : 74,
    down     : 75,
    punch    : 71
});

var alacran2=createCharacter({
    base:scorpio_base2,
    forward:scorpio_move_forward2,
    backward :scorpio_move_backward2,
    crunch : scorpio_crunch2,
    jump: scorpio_jump2,
    player : 2,
    controls :player2Controls,
    fliped : true,
    X: 400,
    direction: -1
});
alacran2.addMove(scorpio_hook2);
alacran2.addMove(scorpio_hp_r2);
alacran2.addMove(scorpio_hp_l2);
detectKeyAction(alacran2);
player2=alacran2;
